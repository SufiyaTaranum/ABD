class Node:
    def __init__(self, reg_no, prog_name, cgpa):
        self.reg_no = reg_no
        self.name = prog_name
        self.cgpa = cgpa
        self.next = None

def merge_sorted_lists(left, right):
    dummy = Node(None, None, None)
    tail = dummy
    
    while left and right:
        if left.cgpa > right.cgpa: 
            tail.next = left
            left = left.next
        else:
            tail.next = right
            right = right.next
        tail = tail.next
    
    if left:
        tail.next = left
    if right:
        tail.next = right
    
    return dummy.next

def find_middle(head):
    if not head or not head.next:
        return head
    slow = head
    fast = head.next
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    return slow

def merge_sort(head):
    if not head or not head.next:
        return head
    middle = find_middle(head)
    next_to_middle = middle.next
    middle.next = None
    left = merge_sort(head)
    right = merge_sort(next_to_middle)
    return merge_sorted_lists(left, right)

def print_list(head):
    while head:
        print(f'Reg No: {head.reg_no}, Prog_name: {head.name}, CGPA: {head.cgpa}')
        head = head.next

def print_program_wise_sorted(head):
    from collections import defaultdict
    program_dict = defaultdict(list)
    
    current = head
    while current:
        program_dict[current.name].append(Node(current.reg_no, current.name, current.cgpa))
        current = current.next
    
    for program, students in sorted(program_dict.items()):
        print(f"\nProgram: {program}")
        sorted_students = merge_sort_list_of_nodes(students)
        while sorted_students:
            print(f'Reg No: {sorted_students.reg_no}, Prog_name: {sorted_students.name}, CGPA: {sorted_students.cgpa}')
            sorted_students = sorted_students.next

def merge_sort_list_of_nodes(node_list):
    if not node_list:
        return None
    head = node_list[0]
    current = head
    for node in node_list[1:]:
        current.next = node
        current = current.next
    return merge_sort(head)

# Example usage
head = Node("101", "BDA", 8.5)
head.next = Node("102", "AIML", 5.6)
head.next.next = Node("103", "BDA", 9.4)
head.next.next.next = Node("104", "AIML", 6.5)
head.next.next.next.next = Node("105", "BDA", 7.3)
head.next.next.next.next.next = Node("106", "AIML", 4.8)

print("List before sorting:")
print_list(head)
print("\nSorted by program and CGPA:")
print_program_wise_sorted(head)
