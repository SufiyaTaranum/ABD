class Node:
    def __init__(self,reg_no,prog_name,cgpa):
        self.reg_no = reg_no
        self.name = prog_name
        self.cgpa = cgpa
        self.next = None

def merge_sorted_lists(left, right):
    if not left:
        return right
    if not right:
        return left
    
    if left.cgpa < right.cgpa:
        left.next = merge_sorted_lists(left.next, right)
        return left
    else:
        right.next = merge_sorted_lists(left, right.next)
        return right

def find_middle(head):
    if not head or not head.next:
        return head
    
    slow = head
    fast = head.next
    
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    
    return slow

def merge_sort(head):
    if not head or not head.next:
         return head
    
    middle = find_middle(head)
    next_to_middle = middle.next
    middle.next = None
    
    left = merge_sort(head)
    right = merge_sort(next_to_middle)
    
    return merge_sorted_lists(left, right)

def print_list(head):
    while head:
        print(f'Reg No: {head.reg_no}, Name: {head.name}, CGPA: {head.cgpa}')
        head = head.next

def sort_and_merge_lists(head1,head2):
    sorted_head1 = merge_sort(head1)
    sorted_head2 = merge_sort(head2)
    return merge_sorted_lists(sorted_head1,sorted_head2)

head1 = Node("101","BDA",8.5)
head1.next=Node("102","BDA",5.6)
head1.next.next=Node("103","BDA",9.4)

head2 = Node("104","AIML",9.5)
head2.next=Node("105","AIML",6.4)
head2.next.next=Node("106","AIML",7.5)

print("first list before sorting")
print_list(head1)

print("second list before sorting")
print_list(head2)

sorted_list = sort_and_merge_lists(head1,head2)

print("\nSorted list")
print_list(sorted_list)
