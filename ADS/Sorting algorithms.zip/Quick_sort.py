import random

def quicksort(mylist):
    _quicksort(mylist, 0, len(mylist) - 1)
    return mylist

def _quicksort(mylist, start, end):
    if start < end:
        pivot_index = random.randint(start, end)
        mylist[pivot_index], mylist[end] = mylist[end], mylist[pivot_index]
        
        mid = _partition(mylist, start, end)
        
        _quicksort(mylist, start, mid - 1)
        _quicksort(mylist, mid + 1, end)

def _partition(mylist, start, end):
    pivot = mylist[end]
    up = start
    down = end - 1
    
    while up <= down:
        while up <= down and mylist[up] <= pivot:
            up += 1
        while up <= down and mylist[down] >= pivot:
            down -= 1
        if up < down:
            mylist[up], mylist[down] = mylist[down], mylist[up]
    
    mylist[up], mylist[end] = mylist[end], mylist[up]
    
    return up

def main():
    array = [40, 70, 20, 60, 10]
    sorted_array = quicksort(array)
    print("Array after sorting is:", sorted_array)

if __name__ == "__main__":
    main()
