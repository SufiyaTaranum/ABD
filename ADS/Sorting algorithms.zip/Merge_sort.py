def mergesort(mylist):
    if len(mylist)<=1:
        return mylist
    else:
        mid=len(mylist)//2
        left=mylist[:mid]
        right=mylist[mid:]
        left=mergesort(left)
        right=mergesort(right)
        return merge(left,right)

def merge(left,right):
    temp=[]
    while len(left)!=0 and len(right)!=0:
        if left[0]<=right[0]:
            temp.append(left.pop(0))
        else:
            temp.append(right.pop(0))
    if len(left)==0:
        temp=temp+right
    else:
        temp=temp+left
    return temp
    
array=[10,60,70,40,30]
sorted_array=mergesort(array)
print("Array after sorting is:",sorted_array)