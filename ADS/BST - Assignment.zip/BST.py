from collections import deque

class BST:
    class _Node_:
        def __init__(self,ele):
            self.data=ele
            self.left=None
            self.right=None

    def __init__(self):
        self.root=None
        self.count=0

    def isEmpty(self):
        return self.count==0
    
    def getCount(self):
        return self.count
    
    def addNode(self,ele):
        cur=parent=self.root
        while cur!=None and ele!=cur.data:
            parent=cur
            if ele<cur.data:
                cur=cur.left
            elif ele>cur.data:
                cur=cur.right
        if cur==None:
            newNode=self._Node_(ele)
            if parent==None:
                self.root=newNode
            elif ele<parent.data:
                parent.left=newNode
            elif ele>parent.data:
                parent.right=newNode
        self.count+=1

    def isMember(self,ele):
        if not self.isEmpty():
            cur=self.root
            while cur!=None:
                if ele<cur.data:
                    cur=cur.left
                elif ele>cur.data:
                    cur=cur.right
                else:
                    break
            return cur!=None
        return False
    
    ##Inorder Tree Traversal
    def bstInorder(self):
        ele = []
        def _inOrder_(node):
            if node:
                _inOrder_(node.left)
                ele.append(node.data)
                _inOrder_(node.right)
        _inOrder_(self.root)
        return ele
    
    ##PreOrder Tree Traversal
    def bstPreorder(self):
        ele = []
        def _preOrder_(node):
            if node:
                ele.append(node.data)
                _preOrder_(node.left)
                _preOrder_(node.right)
        _preOrder_(self.root)
        return ele
    
    ##PostOrder Tree Traversal
    def bstPostorder(self):
        ele = []
        def _postOrder_(node):
            if node:
                _postOrder_(node.left)
                _postOrder_(node.right)
                ele.append(node.data)
        _postOrder_(self.root)
        return ele
    
    ##Find height of a tree
    def findHeight(self):
        def _findHeight(node):
            if node is None:
                return -1  # Base case: height of an empty tree is -1
            left_height = _findHeight(node.left)
            right_height = _findHeight(node.right)
            return 1 + max(left_height, right_height)
        
        return _findHeight(self.root)
    
    def levelOrderTraversal(self):
        ele = []
        if self.root is None:
            print("The tree is empty.")
            return
        queue = deque([self.root])
        while queue:
            node = queue.popleft()
            ele.append(node.data)
            if node.left is not None:
                queue.append(node.left)
            if node.right is not None:
                queue.append(node.right)
        return ele


bst = BST()

nodes_to_add = [15, 10, 20, 8, 12, 16, 25]
for node in nodes_to_add:
    bst.addNode(node)

count=bst.getCount()
print("No of nodes in the BST:",count)

elements_to_check = [10, 25, 30, 5]
for element in elements_to_check:
    is_member = bst.isMember(element)
    print(f"Is {element} in the BST? {'Yes' if is_member else 'No'}")

print("Inorder Traversal:",bst.bstInorder())
print("Preorder Traversal:",bst.bstPreorder())
print("Postorder Traversal:",bst.bstPostorder())
print("Level Order Traversal:",bst.levelOrderTraversal())
print("Height of the BST:",bst.findHeight())