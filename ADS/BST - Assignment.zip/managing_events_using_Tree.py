from datetime import datetime, timedelta

class Event:
    def __init__(self, event_time, name, guests):
        self.event_time = event_time  # datetime object for event start time
        self.name = name
        self.guests = guests

    def __repr__(self):
        return f"{self.event_time.strftime('%Y-%m-%d %H:%M:%S')} - {self.name} ({self.guests} guests)"

class EventBST:
    class _Node:
        def __init__(self, event):
            self.event = event
            self.left = None
            self.right = None

    def __init__(self):
        self.root = None

    def isEmpty(self):
        return self.root is None

    def addEvent(self, event_time, name, guests):
        new_event = Event(event_time, name, guests)
        if self.isEmpty():
            self.root = self._Node(new_event)
        else:
            self._addEvent(self.root, new_event)

    def _addEvent(self, node, new_event):
        if new_event.event_time < node.event.event_time:
            if node.left is None:
                node.left = self._Node(new_event)
            else:
                self._addEvent(node.left, new_event)
        elif new_event.event_time > node.event.event_time:
            if node.right is None:
                node.right = self._Node(new_event)
            else:
                self._addEvent(node.right, new_event)
        else:
            print("Event with this time already exists.")

    def cancelEvent(self, event_time):
        if not self.isEmpty():
            self.root, deleted = self._cancelEvent(self.root, event_time)
            if deleted:
                print(f"Event at {event_time} canceled.")
            else:
                print(f"No event found at {event_time}.")

    def _cancelEvent(self, node, event_time):
        if node is None:
            return node, False
        
        deleted = False
        if event_time < node.event.event_time:
            node.left, deleted = self._cancelEvent(node.left, event_time)
        elif event_time > node.event.event_time:
            node.right, deleted = self._cancelEvent(node.right, event_time)
        else:
            # Node to be deleted
            if node.left is None:
                return node.right, True
            elif node.right is None:
                return node.left, True

            minNode = self._findMin(node.right)
            node.event = minNode.event
            node.right, _ = self._cancelEvent(node.right, minNode.event.event_time)
            deleted = True
        
        return node, deleted

    def _findMin(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def deleteCompletedEvents(self):
        if not self.isEmpty():
            self.root = self._deleteCompletedEvents(self.root)

    def _deleteCompletedEvents(self, node):
        if node is None:
            return None
        
        node.left = self._deleteCompletedEvents(node.left)
        node.right = self._deleteCompletedEvents(node.right)

        # Assuming events before current date are completed
        if node.event.event_time < datetime.now():
            return self._deleteNode(node.event.event_time)
        
        return node

    def _deleteNode(self, event_time):
        self.root, _ = self._cancelEvent(self.root, event_time)
        return self.root

    def displayEventsDescending(self):
        events = []
        self._inOrder(self.root, events)
        for event in reversed(events):
            print(event)

    def _inOrder(self, node, events):
        if node is not None:
            self._inOrder(node.left, events)
            events.append(node.event)
            self._inOrder(node.right, events)

# Example usage
event_bst = EventBST()

# Adding events
event_bst.addEvent(datetime(2024, 9, 12, 10, 0), 'Event A', 50)
event_bst.addEvent(datetime(2024, 9, 12, 14, 0), 'Event B', 30)
event_bst.addEvent(datetime(2024, 9, 13, 9, 0), 'Event C', 40)

print("All events (descending order):")
event_bst.displayEventsDescending()

# Cancel an event
event_bst.cancelEvent(datetime(2024, 9, 12, 10, 0))

print("\nEvents after cancellation (descending order):")
event_bst.displayEventsDescending()

# Delete completed events (assuming now is in the past relative to event times)
event_bst.deleteCompletedEvents()

print("\nEvents after deleting completed events (descending order):")
event_bst.displayEventsDescending()
