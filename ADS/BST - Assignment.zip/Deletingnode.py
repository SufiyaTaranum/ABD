### Deleting a node from binary tree and printing tree inorder traversal
class BST:
    class _Node_:
        def __init__(self, ele):
            self.data = ele
            self.left = None
            self.right = None

    def __init__(self):
        self.root = None
        self.count = 0

    def isEmpty(self):
        return self.count == 0
    
    def getCount(self):
        return self.count
    
    def addNode(self, ele):
        cur = parent = None
        if self.root is None:
            self.root = self._Node_(ele)
            self.count += 1
        else:
            cur = self.root
            while cur is not None and ele != cur.data:
                parent = cur
                if ele < cur.data:
                    cur = cur.left
                else:
                    cur = cur.right
            
            if cur is None:
                newNode = self._Node_(ele)
                if ele < parent.data:
                    parent.left = newNode
                else:
                    parent.right = newNode
                self.count += 1

    def deleteNode(self, key):
        if not self.isEmpty():
            self.root, deleted = self._deletenode(self.root, key)
            if deleted:
                self.count -= 1

    def _deletenode(self, node, key):
        if node is None:
            return node, False
        
        deleted = False
        if key < node.data:
            node.left, deleted = self._deletenode(node.left, key)
        elif key > node.data:
            node.right, deleted = self._deletenode(node.right, key)
        else:
            # Node with only one child or no child
            if node.left is None:
                return node.right, True
            elif node.right is None:
                return node.left, True
            
            # Node with two children
            minNode = self._findMin(node.right)
            node.data = minNode.data
            node.right, _ = self._deletenode(node.right, minNode.data)
            deleted = True
        
        return node, deleted

    def _findMin(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current
    
    def printTree(self):
        if not self.isEmpty():
            self._printInOrder(self.root)
        else:
            print("The tree is empty.")
    
    def _printInOrder(self, node):
        if node is not None:
            self._printInOrder(node.left)
            print(node.data, end=' ')
            self._printInOrder(node.right)

# Example usage
bst = BST()

nodes_to_add = [15, 10, 20, 8, 12, 16, 25]
for node in nodes_to_add:
    bst.addNode(node)

print("Original BST:")
bst.printTree()
print("\nNo of nodes in the BST:", bst.getCount())

DelNode = int(input("Enter node to delete: "))
bst.deleteNode(DelNode)

print("Tree after deletion:")
bst.printTree()
print("\nNo of nodes in the BST:", bst.getCount())
